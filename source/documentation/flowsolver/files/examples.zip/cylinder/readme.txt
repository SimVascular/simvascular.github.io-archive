This example is a cylinder with steady parabolic flow at the inlet and resistance boundary condition on the outlet

Folder: mesh-complete
----------------------
All the files in this folder are from SimVascualr meshing output and contain geometry, mesh, surfaces of interest.

Folder: flow-files
------------------
steady.flow provide flowrate for the inlet.

cylinder.svpre
---------------
The script file for presolver.

bct.dat (bct.vtp)
-----------------
It's created by presolver or from GUI and prescribes the velocity of the inlet.

restart.0.1
-----------
It's created by presolver and contains inital values for velocity, pressure, ect.

geombc.dat.1
------------
It's created by presolver and contains geometry, mesh, material properties.

numstart.dat
------------
It's created from presolver GUI and indicates the starting time step for simulation.

solver.inp
----------
The input file for flowsolver to run simulation

Folder: 4-procs_case
--------------------
It includes all simulation result files from flowsover from time step 0 to 200 by interval 10.

all_results_000xx.vtu (.vtp)
----------------------------
These vtu (vtp) files are created from postprocessing and include the data for velocity, pressure, ect from time step 0 to 200 by interval 10.

average_results.vtp
-------------------
It's created from postprocessing and shows average pressure, oscillatory shear index (OSI).

all_results.vtu (.vtp)
----------------------
It's a combo file produced from postprocessing when "Single File" is on in the GUI, and include all the data for all time steps.

all_results_averages.txt (all_results_averages-from_cm-to-mmHg-L_per_min.txt)
-----------------------------------------------------------------------------
It's created from postprocessing and include statistical data of pressure, flowrate for the inlet and outlet.

all_results-flows.txt, all results-pressures
--------------------------------------------
It's created from postprocessing and include pressure, flowrate for the inlet and outlet with time.


